import { createServerFn } from "@tanstack/react-start";

import {
  MASTER_SYSTEM_PROMPT,
  SECTION_PROMPTS,
  STAGE_PROMPTS,
  renderLessonContext,
  type LessonRequest,
} from "@/config/teacherflow-prompt";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { generateStructured, LessonGenerationError } from "@/lib/ai-service.server";
import { findTechTerms, isNoTechRequest, noTechRepairInstruction } from "@/lib/no-tech";
import {
  SECTION_SCHEMAS,
  assessmentSchema,
  differentiationSchema,
  foundationSchema,
  lessonRequestSchema,
  materialsSchema,
  type LessonPackage,
  type SectionKeyName,
} from "@/lib/lesson-schema";

/**
 * Generates content and, when the class has no technology, automatically
 * rewrites any output that still depends on electronic equipment.
 */
async function generateNoTechSafe<T>(args: {
  schema: Parameters<typeof generateStructured>[0]["schema"];
  schemaName: string;
  system: string;
  input: string;
  noTech: boolean;
}): Promise<T> {
  const first = await generateStructured({
    schema: args.schema,
    schemaName: args.schemaName,
    system: args.system,
    input: args.input,
  });
  if (!args.noTech) return first as T;

  let current = first;
  for (let attempt = 0; attempt < 1; attempt++) {
    const found = findTechTerms(current);
    if (!found.length) break;
    console.warn(`[no-tech] repairing ${args.schemaName}: ${found.join(", ")}`);
    current = await generateStructured({
      schema: args.schema,
      schemaName: args.schemaName,
      system: args.system,
      input: `${args.input}\n\nPREVIOUS OUTPUT (must be revised)\n${JSON.stringify(
        current,
      )}\n\n${noTechRepairInstruction(found)}`,
    });
  }
  return current as T;
}



type StageName = "foundation" | "materials" | "assessment" | "differentiation";

function friendly(error: unknown): never {
  if (error instanceof LessonGenerationError) throw new Error(error.message);
  console.error(error);
  throw new Error("Something went wrong while building the class. Your inputs are safe — please retry.");
}

function contextBlock(request: LessonRequest, prior: Partial<LessonPackage>): string {
  const parts = [renderLessonContext(request)];
  if (prior.overview) {
    parts.push(`ALREADY DESIGNED — LESSON OVERVIEW\n${JSON.stringify(prior.overview)}`);
  }
  if (prior.lessonPlan) {
    parts.push(`ALREADY DESIGNED — LESSON PLAN\n${JSON.stringify(prior.lessonPlan)}`);
  }
  if (prior.worksheet) {
    parts.push(`ALREADY DESIGNED — WORKSHEET\n${JSON.stringify(prior.worksheet)}`);
  }
  if (prior.assessment) {
    parts.push(`ALREADY DESIGNED — ASSESSMENT\n${JSON.stringify(prior.assessment)}`);
  }
  parts.push("Stay perfectly consistent with everything already designed above.");
  return parts.join("\n\n");
}

/**
 * One generation pass. The client calls this once per stage so the progress the
 * teacher sees reflects real application state, not a timer.
 */
export const generateLessonStage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => {
    const parsed = lessonRequestSchema.parse((input as { request: unknown }).request);
    const stage = (input as { stage: StageName }).stage;
    const prior = ((input as { prior?: Partial<LessonPackage> }).prior ?? {}) as Partial<LessonPackage>;
    return { request: parsed, stage, prior };
  })
  .handler(async ({ data }) => {
    const { request, stage, prior } = data;
    const schemas = {
      foundation: foundationSchema,
      materials: materialsSchema,
      assessment: assessmentSchema,
      differentiation: differentiationSchema,
    } as const;

    try {
      const result = await generateNoTechSafe<Partial<LessonPackage>>({
        schema: schemas[stage],
        schemaName: `teacherflow_${stage}`,
        system: MASTER_SYSTEM_PROMPT,
        input: `${contextBlock(request, prior)}\n\n${STAGE_PROMPTS[stage]}`,
        noTech: isNoTechRequest(request.technologyAvailable),
      });
      return result;

    } catch (error) {
      friendly(error);
    }
  });

export const saveLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => {
    const i = input as { request: unknown; content: LessonPackage };
    return { request: lessonRequestSchema.parse(i.request), content: i.content };
  })
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const r = data.request;
    const { data: row, error } = await supabase
      .from("lessons")
      .insert({
        user_id: userId,
        topic: r.topic,
        subject: r.subject,
        student_age: r.studentAge,
        level: r.level,
        duration_minutes: r.durationMinutes,
        main_skill: r.mainSkill,
        learning_objective: r.learningObjective,
        inputs: r,
        content: data.content,
      })
      .select("id")
      .single();

    if (error) {
      console.error(error);
      throw new Error("We could not save this lesson. Please try again.");
    }
    return { id: row.id as string };
  });

export const listLessons = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("lessons")
      .select("id, topic, level, student_age, duration_minutes, main_skill, created_at")
      .order("created_at", { ascending: false });
    if (error) {
      console.error(error);
      throw new Error("We could not load your lessons.");
    }
    return data ?? [];
  });

export const getLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("lessons")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) {
      console.error(error);
      throw new Error("We could not open this lesson.");
    }
    if (!row) throw new Error("This lesson could not be found.");
    return row;
  });

export const deleteLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("lessons").delete().eq("id", data.id);
    if (error) {
      console.error(error);
      throw new Error("We could not delete this lesson.");
    }
    return { ok: true };
  });

/* ------------------ Phase 4: edit, regenerate, duplicate ------------------ */

/** Everything the model needs to keep a regenerated section consistent. */
function regenerationContext(request: LessonRequest, lesson: LessonPackage, skip: SectionKeyName): string {
  const parts = [renderLessonContext(request)];
  parts.push(`ALREADY DESIGNED — LESSON OVERVIEW\n${JSON.stringify(lesson.overview)}`);
  parts.push(`ALREADY DESIGNED — LESSON PLAN\n${JSON.stringify(lesson.lessonPlan)}`);
  if (skip !== "worksheet" && lesson.worksheet) {
    parts.push(`ALREADY DESIGNED — WORKSHEET (student side)\n${JSON.stringify(lesson.worksheet)}`);
  }
  if (skip !== "activity" && lesson.activity) {
    parts.push(`ALREADY DESIGNED — CLASSROOM ACTIVITY\n${JSON.stringify(lesson.activity)}`);
  }
  if (skip !== "assessment" && lesson.assessment) {
    parts.push(`ALREADY DESIGNED — ASSESSMENT\n${JSON.stringify(lesson.assessment)}`);
  }
  parts.push(
    "Regenerate ONLY the requested component. Everything else above is fixed and must stay valid.",
  );
  return parts.join("\n\n");
}

export const regenerateSection = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => {
    const i = input as { request: unknown; lesson: LessonPackage; section: SectionKeyName };
    return {
      request: lessonRequestSchema.parse(i.request),
      lesson: i.lesson,
      section: i.section,
    };
  })
  .handler(async ({ data }) => {
    const { request, lesson, section } = data;
    const schema = SECTION_SCHEMAS[section];
    if (!schema) throw new Error("That part of the lesson cannot be regenerated.");
    try {
      const result = await generateNoTechSafe<Partial<LessonPackage>>({
        schema,
        schemaName: `teacherflow_section_${section}`,
        system: MASTER_SYSTEM_PROMPT,
        input: `${regenerationContext(request, lesson, section)}\n\n${SECTION_PROMPTS[section]}`,
        noTech: isNoTechRequest(request.technologyAvailable),
      });
      return result;

    } catch (error) {
      friendly(error);
    }
  });

/** Saves teacher edits (or a regenerated section) back onto a stored lesson. */
export const updateLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => {
    const i = input as { id: string; content: LessonPackage };
    return { id: i.id, content: i.content };
  })
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("lessons")
      .update({ content: data.content, updated_at: new Date().toISOString() })
      .eq("id", data.id);
    if (error) {
      console.error(error);
      throw new Error("We could not save your changes. Your lesson is safe — please try again.");
    }
    return { ok: true };
  });

/** Copies a saved lesson so a teacher can adapt it for another class. */
export const duplicateLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("lessons")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error || !row) {
      console.error(error);
      throw new Error("We could not duplicate this lesson.");
    }
    const { data: copy, error: insertError } = await supabase
      .from("lessons")
      .insert({
        user_id: userId,
        topic: `${row.topic} (copy)`,
        subject: row.subject,
        student_age: row.student_age,
        level: row.level,
        duration_minutes: row.duration_minutes,
        main_skill: row.main_skill,
        learning_objective: row.learning_objective,
        inputs: row.inputs,
        content: row.content,
      })
      .select("id")
      .single();
    if (insertError) {
      console.error(insertError);
      throw new Error("We could not duplicate this lesson.");
    }
    return { id: copy.id as string };
  });
